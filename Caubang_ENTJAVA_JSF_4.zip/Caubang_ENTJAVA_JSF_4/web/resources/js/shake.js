document.addEventListener("DOMContentLoaded", function(event){
	document.getElementById("item-form").style.animation = "shake .5s";
});

package apc.ppc.megijsf;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;

import apc.ppc.megiejb.*;

@Named
@ConversationScoped
public class GameTransactionBean implements Serializable{

    private long itemId;

    private int money;

    private InventoryItem item;

    @Inject
    private InventoryLocal inventoryBean;

    @Inject
    private Conversation conversation;

    public void fetchItem() {
        conversation.begin();
        this.item=inventoryBean.findItem(this.itemId);
    }

    public long getItemId() {
        return itemId;
    }

    public void setItemId(long itemId) {
        this.itemId = itemId;
    }

    public InventoryItem getItem() {
        return item;
    }

    public void setItem(InventoryItem item) {
        this.item = item;
    }

    public InventoryLocal getInventoryBean() {
        return inventoryBean;
    }

    public void setInventoryBean(InventoryLocal inventoryBean) {
        this.inventoryBean = inventoryBean;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }
}

package apc.ppc.megijsf;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import apc.ppc.megiejb.*;


@RequestScoped
@Named
public class GameInventoryBean implements Serializable {

    @Inject
    private InventoryLocal inventoryBean;

    private Users user = new Users();

    private List<InventoryItem> inventory = new ArrayList<>();

    public String createInventory() {
        this.inventoryBean.addItem(new InventoryItem("Sword",50));
        this.inventoryBean.addItem(new InventoryItem("Pickaxe",100));
        this.inventoryBean.addItem(new InventoryItem("Helmet",450));
        this.inventoryBean.addItem(new InventoryItem("Shield",200));
        this.inventoryBean.addItem(new InventoryItem("Spear",300));
        this.inventoryBean.addItem(new InventoryItem("Wood Planks",100));
        this.inventoryBean.addItem(new InventoryItem("Torches",150));
        this.inventoryBean.addItem(new InventoryItem("Crafting Table",200));
        this.inventoryBean.addItem(new InventoryItem("Furnace",300));
        this.inventoryBean.addItem(new InventoryItem("Chest",350));
        this.inventoryBean.addItem(new InventoryItem("Wood Axe",250));
        this.inventoryBean.addItem(new InventoryItem("Bow",250));
        this.inventoryBean.addItem(new InventoryItem("Books",250));
        this.inventoryBean.addItem(new InventoryItem("Raw Chicken",150));
        this.inventoryBean.addItem(new InventoryItem("Raw Meat",150));
        this.inventoryBean.addItem(new InventoryItem("Wool",50));
        this.inventoryBean.addItem(new InventoryItem("Fishing Rod",200));
        this.inventoryBean.addItem(new InventoryItem("Stick",100));
        this.inventoryBean.addItem(new InventoryItem("Paper",20));
        this.inventoryBean.addItem(new InventoryItem("Flint",400));
        this.inventoryBean.addItem(new InventoryItem("Leather",200));
        this.inventoryBean.addItem(new InventoryItem("Glass",350));
        this.inventoryBean.addItem(new InventoryItem("Coal",200));
        this.inventoryBean.addItem(new InventoryItem("Bricks",250));
        this.inventoryBean.addItem(new InventoryItem("Wheat",150));
        this.inventoryBean.addItem(new InventoryItem("Wood Planks",100));
        this.inventoryBean.addItem(new InventoryItem("TNT",250));
        this.inventoryBean.addItem(new InventoryItem("Bowl",200));
        this.inventoryBean.addItem(new InventoryItem("Banner",200));
        this.inventoryBean.addItem(new InventoryItem("Door",400));
        return "inventory?faces-redirect=true";
    }

    public void init() {
        this.inventory = this.inventoryBean.getItems();
    }

    public InventoryLocal getInventoryBean() {
        return inventoryBean;
    }

    public void setInventoryBean(InventoryLocal inventoryBean) {
        this.inventoryBean = inventoryBean;
    }

    public List<InventoryItem> getInventory() {
        return inventory;
    }

    public void setInventory(List<InventoryItem> inventory) {
        this.inventory = inventory;
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }
}
package apc.ppc.megiejb;

import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Singleton
@LocalBean
public class Transactions implements TransactionsLocal {

	@PersistenceContext
	private EntityManager entityManager;

    public Transactions() {
    }

	@Override
	public List<TransactionHistory> getItems() {
		return this.entityManager.createQuery("select t from TransactionHistory t", TransactionHistory.class).getResultList();
	}

	@Override
	public void addItem(TransactionHistory item) {
		this.entityManager.persist(item);
	}

	@Override
	public void deleteItem(TransactionHistory item) {
		this.entityManager.remove(this.entityManager.contains(item) ? item:this.entityManager.merge(item));
	}

	@Override
	public void updateItem(TransactionHistory item) {
		this.entityManager.createQuery("update TransactionHistory t set t.name=:itemName, t.actionDone=:itemActionDone, t.value=:itemValue, t.dateOfTransacttion where t.itemId=:id")
				.setParameter("id", item.getItemId())
				.setParameter("itemName", item.getName())
				.setParameter("itemActionDone", item.getActionDone())
				.setParameter("itemValue", item.getValue())
				.setParameter("itemDateOfTransaction", item.getDateOfTransaction())
				.executeUpdate();
	}


	@Override
	public TransactionHistory findItem(Long itemId) {
		return this.entityManager.find(TransactionHistory.class, itemId);
	}

	@Override
	public List<TransactionHistory> searchByName(String name) {
		return this.entityManager.createQuery("select t from TransactionHistory t " +
				" where t.name like :name", TransactionHistory.class).setParameter("name", "%" + name + "%").getResultList();
	}

}

package apc.ppc.megiejb;

public class Users {

    private String userName = "Steve";

    private int money = 10000;

    public Users() {
    }

    public Users(String userName, String password) {
        super();
        this.userName = userName;
        this.money = money;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    @Override
    public String toString() {
        return "Users{" +
                "userName='" + userName + '\'' +
                ", money=" + money +
                '}';
    }
}

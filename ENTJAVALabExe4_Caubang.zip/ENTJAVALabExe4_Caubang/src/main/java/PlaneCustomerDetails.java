import java.util.Date;

public class PlaneCustomerDetails {
    private String fName;
    private String lName;
    private Date birthDate;
    private String flightId;

    public PlaneCustomerDetails() {
    }

    public PlaneCustomerDetails(String fName, String lName, Date birthDate, String flightId) {
        this.fName = fName;
        this.lName = lName;
        this.birthDate = birthDate;
        this.flightId = flightId;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getFlightId() {
        return flightId;
    }

    public void setFlightId(String flightId) {
        this.flightId = flightId;
    }

}

public class PlaneFlights {

    private String flightPlace1 = "Manila";
    private String flightPlace2 = "Cebu";
    private String flightPlace3 = "Kalibo";

    private String MNL001 = flightPlace1 + " - " + flightPlace2;
    private String MNL002 = flightPlace1 + " - " + flightPlace3;
    private String MNL003 = flightPlace2 + " - " + flightPlace1;
    private String MNL004 = flightPlace3 + " - " + flightPlace1;

    public PlaneFlights() {
    }

    public PlaneFlights(String MNL001, String MNL002, String MNL003, String MNL004) {
        this.MNL001 = MNL001;
        this.MNL002 = MNL002;
        this.MNL003 = MNL003;
        this.MNL004 = MNL004;
    }

    public String getMNL001() {
        return MNL001;
    }

    public void setMNL001(String MNL001) {
        this.MNL001 = MNL001;
    }

    public String getMNL002() {
        return MNL002;
    }

    public void setMNL002(String MNL002) {
        this.MNL002 = MNL002;
    }

    public String getMNL003() {
        return MNL003;
    }

    public void setMNL003(String MNL003) {
        this.MNL003 = MNL003;
    }

    public String getMNL004() {
        return MNL004;
    }

    public void setMNL004(String MNL004) {
        this.MNL004 = MNL004;
    }
}

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named
@SessionScoped
public class PlaneTicket implements Serializable {
    private PlaneCustomerDetails detail = new PlaneCustomerDetails();
    private List<PlaneCustomerDetails> details = new ArrayList<>();
    private PlaneFlights flightDetails = new PlaneFlights();
    private String flightDetail;
    private int ticketFare;

    public String addTicketDetails() {
        this.details.add(new PlaneCustomerDetails(this.detail.getfName(), this.detail.getlName(), this.detail.getBirthDate(), this.detail.getFlightId()));
        updateTicketDetails(this.detail.getFlightId());
        this.details.stream().forEach(detail->{
            System.out.println(detail.toString());
        });
        return "ticket?faces-redirect=true";
    }

    public void updateTicketDetails(String flightId) {

        if(flightId.equals("MNL001")) {
            this.ticketFare = 3500;
            this.flightDetail = this.detail.getFlightId() + " " + this.flightDetails.getMNL001();
        } else if(flightId.equals("MNL002")){
            this.ticketFare = 2500;
            this.flightDetail = this.detail.getFlightId() + " " + this.flightDetails.getMNL002();
        } else if(flightId.equals("MNL003")) {
            this.ticketFare = 3700;
            this.flightDetail = this.detail.getFlightId() + " " + this.flightDetails.getMNL003();
        } else {
            this.ticketFare = 2700;
            this.flightDetail = this.detail.getFlightId() + " " + this.flightDetails.getMNL004();
        }
    }

    public PlaneCustomerDetails getDetail() {
        return detail;
    }

    public void setDetail(PlaneCustomerDetails detail) {
        this.detail = detail;
    }

    public List<PlaneCustomerDetails> getDetails() {
        return details;
    }

    public void setDetails(List<PlaneCustomerDetails> details) {
        this.details = details;
    }

    public void setFlightDetails(PlaneFlights flightDetails) {
        this.flightDetails = flightDetails;
    }

    public PlaneFlights getFlightDetails() {
        return flightDetails;
    }

    public String getFlightDetail() {
        return flightDetail;
    }

    public void setFlightDetail(String flightDetail) {
        this.flightDetail = flightDetail;
    }

    public int getTicketFare() {
        return ticketFare;
    }

    public void setTicketFare(int ticketFare) {
        this.ticketFare = ticketFare;
    }

}

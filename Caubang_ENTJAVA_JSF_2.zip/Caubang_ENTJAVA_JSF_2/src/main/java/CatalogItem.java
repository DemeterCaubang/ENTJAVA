import java.util.Date;

public class CatalogItem {

    private long itemId;
    private String name;
    private String manufacturer;
    private Date availableDate;
	private String description;

    public CatalogItem() {

    }

    public CatalogItem(Long itemId, String name, String manufacturer, Date availableDate, String description) {
        this.itemId = itemId;
        this.name = name;
        this.manufacturer = manufacturer;
        this.availableDate = availableDate;
        this.description = description;
    }

    public long getItemId() {
        return itemId;
    }

    public void setItemId(long itemId) {
        this.itemId = itemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public Date getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(Date availableDate) {
        this.availableDate = availableDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "CatalogItem{" +
                "itemId=" + itemId +
                ", name='" + name + '\'' +
                ", manufacturer='" + manufacturer + '\'' +
                ", availableDate=" + availableDate +
                ", description='" + description + '\'' +
                '}';
    }
}

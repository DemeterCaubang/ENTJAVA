package apc.ppc.ejbmegi;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="TRANSACTION_HISTORY")
public class TransactionHistory {

    @Id
    @Column(name="TRANSACTION_HISTORY_ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long itemId;

    @Column(name="NAME")
    private String name;

    @Column(name="ACTION")
    private String action;

    @Column(name="VALUE")
    private int value;

    @Column(name="DATE_OF_TRANSACTION")
    private Date dateOfTransaction;

    public TransactionHistory() {
    }

    public TransactionHistory(String name, String action, int value, Date dateOfTransaction) {
        super();
        this.name = name;
        this.action = action;
        this.value = value;
        this.dateOfTransaction = dateOfTransaction;
    }

    public long getItemId() {
        return itemId;
    }

    public void setItemId(long itemId) {
        this.itemId = itemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getAction() {
        return action;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public Date getDateOfTransaction() {
        return dateOfTransaction;
    }

    public void setDateOfTransaction(Date dateOfTransaction) {
        this.dateOfTransaction = dateOfTransaction;
    }

    @Override
    public String toString() {
        return "TransactionHistory{" +
                "itemId=" + itemId +
                ", name='" + name + '\'' +
                ", action='" + action + '\'' +
                ", value=" + value +
                ", dateOfTransaction=" + dateOfTransaction +
                '}';
    }
}

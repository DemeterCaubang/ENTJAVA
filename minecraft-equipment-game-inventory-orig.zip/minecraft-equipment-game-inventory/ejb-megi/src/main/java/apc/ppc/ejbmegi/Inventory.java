package apc.ppc.ejbmegi;

import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Singleton
@LocalBean
public class Inventory implements InventoryLocal{
    @PersistenceContext
    private EntityManager entityManager;

    public Inventory() {
    }

    @Override
    public List<InventoryItem> getItems() {
        return this.entityManager.createQuery("select i from InventoryItem i", InventoryItem.class).getResultList();
    }

    @Override
    public void addItem(InventoryItem item) {
        this.entityManager.persist(item);
    }

    @Override
    public void clearInventory() {
        this.entityManager.clear();
    }

    @Override
    public InventoryItem findItem(Long itemId) {
        return this.entityManager.find(InventoryItem.class, itemId);
    }

}

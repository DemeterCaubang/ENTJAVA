package apc.ppc.ejbmegi;

import javax.ejb.Local;
import java.util.List;

@Local
public interface InventoryLocal {

    public List<InventoryItem> getItems();

    public void addItem(InventoryItem item);

    public void clearInventory();

    InventoryItem findItem(Long itemId);

}

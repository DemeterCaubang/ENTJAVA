package apc.ppc.ejbmegi;

import javax.persistence.*;

@Entity
@Table(name="INVENTORY_ITEM")
public class InventoryItem {

    @Id
    @Column(name="INVENTORY_ITEM_ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long itemId;

    @Column(name = "NAME")
    private String name;

    @Column(name = "BUYING_PRICE")
    private int buyingPrice;

    public InventoryItem() {
    }

    public InventoryItem(String name, int buyingPrice) {
        super();
        this.name = name;
        this.buyingPrice = buyingPrice;
    }

    public long getItemId() {
        return itemId;
    }

    public void setItemId(long itemId) {
        this.itemId = itemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBuyingPrice() {
        return buyingPrice;
    }

    public void setBuyingPrice(int buyingPrice) {
        this.buyingPrice = buyingPrice;
    }

    @Override
    public String toString() {
        return "InventoryItem{" +
                "itemId=" + itemId +
                ", name='" + name + '\'' +
                ", buyingPrice='" + buyingPrice + '\'' +
                '}';
    }
}
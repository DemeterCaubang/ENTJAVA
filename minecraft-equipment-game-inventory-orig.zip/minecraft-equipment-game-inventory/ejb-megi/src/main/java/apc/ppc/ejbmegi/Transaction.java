package apc.ppc.ejbmegi;


import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Singleton
@LocalBean
public class Transaction implements TransactionLocal{
    @PersistenceContext
    private EntityManager entityManager;

    public Transaction() {
    }

    @Override
    public List<TransactionHistory> getItems() {
        return this.entityManager.createQuery("select t from TransactionHistory t", TransactionHistory.class).getResultList();
    }

    @Override
    public void addItem(TransactionHistory item) {
        this.entityManager.persist(item);
    }

    @Override
    public void clearHistory() {
        this.entityManager.clear();
    }

}


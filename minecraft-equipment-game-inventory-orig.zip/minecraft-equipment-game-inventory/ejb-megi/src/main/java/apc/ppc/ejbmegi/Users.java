package apc.ppc.ejbmegi;

public class Users {
    private String playerName= "Player";
    private int money = 10000;

    public Users() {
    }

    public Users(String playerName, int money) {
        this.playerName = playerName;
        this.money = money;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    @Override
    public String toString() {
        return "Users{" +
                "playerName='" + playerName + '\'' +
                ", money=" + money +
                '}';
    }
}

package apc.ppc.ejbmegi;

import javax.ejb.Local;
import java.util.List;

@Local
public interface TransactionLocal {

    public List<TransactionHistory> getItems();

    public void addItem(TransactionHistory item);

    public void clearHistory();

}

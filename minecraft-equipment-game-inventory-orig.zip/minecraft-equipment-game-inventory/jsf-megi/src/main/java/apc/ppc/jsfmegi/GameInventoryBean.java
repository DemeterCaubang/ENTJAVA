package apc.ppc.jsfmegi;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import java.util.ArrayList;
import java.util.List;
import apc.ppc.ejbmegi.*;

@Named
@RequestScoped
public class GameInventoryBean {

    // create an instance of local bean
    @Inject
    private InventoryLocal inventoryBean;

    // create an instances of EJB classes
    private Users user = new Users();
    private InventoryItem item = new InventoryItem();
    private List<InventoryItem> inventory = new ArrayList<>();

    //hold username
    private String username;

    public String init() {
        this.inventoryBean.clearInventory();
        this.inventoryBean.addItem(new InventoryItem("Sword",50));
        this.inventoryBean.addItem(new InventoryItem("Pickaxe",100));
        this.inventoryBean.addItem(new InventoryItem("Helmet",450));
        this.inventoryBean.addItem(new InventoryItem("Shield",200));
        this.inventoryBean.addItem(new InventoryItem("Spear",300));
        this.inventoryBean.addItem(new InventoryItem("Wood Planks",100));
        this.inventoryBean.addItem(new InventoryItem("Torches",150));
        this.inventoryBean.addItem(new InventoryItem("Crafting Table",200));
        this.inventoryBean.addItem(new InventoryItem("Furnace",300));
        this.inventoryBean.addItem(new InventoryItem("Chest",350));
        this.inventoryBean.addItem(new InventoryItem("Wood Axe",250));
        this.inventoryBean.addItem(new InventoryItem("Bow",250));
        this.inventoryBean.addItem(new InventoryItem("Books",250));
        this.inventoryBean.addItem(new InventoryItem("Raw Chicken",150));
        this.inventoryBean.addItem(new InventoryItem("Raw Meat",150));
        this.inventoryBean.addItem(new InventoryItem("Wool",50));
        this.inventoryBean.addItem(new InventoryItem("Fishing Rod",200));
        this.inventoryBean.addItem(new InventoryItem("Stick",100));
        this.inventoryBean.addItem(new InventoryItem("Paper",20));
        this.inventoryBean.addItem(new InventoryItem("Flint",400));
        this.inventoryBean.addItem(new InventoryItem("Leather",200));
        this.inventoryBean.addItem(new InventoryItem("Glass",350));
        this.inventoryBean.addItem(new InventoryItem("Coal",200));
        this.inventoryBean.addItem(new InventoryItem("Bricks",250));
        this.inventoryBean.addItem(new InventoryItem("Wheat",150));
        this.inventoryBean.addItem(new InventoryItem("Wood Planks",100));
        this.inventoryBean.addItem(new InventoryItem("TNT",250));
        this.inventoryBean.addItem(new InventoryItem("Bowl",200));
        this.inventoryBean.addItem(new InventoryItem("Banner",200));
        this.inventoryBean.addItem(new InventoryItem("Door",400));
        this.user.setPlayerName(this.username);
        return "index?faces-redirect=true";
    }

    public void loadInventory() {
        this.inventory.clear();
        this.inventory = this.inventoryBean.getItems();
    }

    public InventoryItem getItem() {
        return item;
    }

    public void setItem(InventoryItem item) {
        this.item = item;
    }

    public List<InventoryItem> getInventory() {
        return inventory;
    }

    public void setInventory(List<InventoryItem> inventory) {
        this.inventory = inventory;
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public InventoryLocal getInventoryBean() {
        return inventoryBean;
    }

    public void setInventoryBean(InventoryLocal inventoryBean) {
        this.inventoryBean = inventoryBean;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}

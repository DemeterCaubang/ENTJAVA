package apc.ppc.jsfmegi;

import apc.ppc.ejbmegi.*;

import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named
@ConversationScoped
public class GameTransactionBean implements Serializable {
    private long itemId;

    private InventoryItem currentItem;

    @Inject
    private GameInventoryBean gameInventoryBean;

    @Inject
    private InventoryLocal inventoryBean;

    @Inject
    private TransactionLocal transactionBean;

    @Inject
    private Conversation conversation;

    private List<TransactionHistory> history = new ArrayList<>();

    public void fetchItem() {
        conversation.begin();
        this.currentItem=inventoryBean.findItem(this.itemId);
    }

    public String buyItem() {
        int money = gameInventoryBean.getUser().getMoney();
        int buyingPrice = this.currentItem.getBuyingPrice();
        this.gameInventoryBean.getUser().setMoney(money - buyingPrice);
        java.util.Date date = new java.util.Date();
        this.transactionBean.addItem(new TransactionHistory(currentItem.getName(),"buy", buyingPrice, date));
        return "buyerReceipt?faces-redirect=true";
    }

    public String sellItem() {
        int money = gameInventoryBean.getUser().getMoney();
        int sellingPrice = this.currentItem.getBuyingPrice() + 50;
        this.gameInventoryBean.getUser().setMoney(money + sellingPrice);
        java.util.Date date = new java.util.Date();
        this.transactionBean.addItem(new TransactionHistory(currentItem.getName(),"sell", sellingPrice, date));
        return "sellerReceipt?faces-redirect=true";
    }

    public void loadHistory() {
        this.setHistory(this.transactionBean.getItems());
    }

    public void cleanHistory() {
        this.transactionBean.clearHistory();
    }

    public long getItemId() {
        return itemId;
    }

    public void setItemId(long itemId) {
        this.itemId = itemId;
    }

    public InventoryItem getCurrentItem() {
        return currentItem;
    }

    public void setCurrentItem(InventoryItem currentItem) {
        this.currentItem = currentItem;
    }

    public GameInventoryBean getGameInventoryBean() {
        return gameInventoryBean;
    }

    public void setGameInventoryBean(GameInventoryBean gameInventoryBean) {
        this.gameInventoryBean = gameInventoryBean;
    }

    public InventoryLocal getInventoryBean() {
        return inventoryBean;
    }

    public void setInventoryBean(InventoryLocal inventoryBean) {
        this.inventoryBean = inventoryBean;
    }

    public Conversation getConversation() {
        return conversation;
    }

    public void setConversation(Conversation conversation) {
        this.conversation = conversation;
    }

    public TransactionLocal getTransactionBean() {
        return transactionBean;
    }

    public void setTransactionBean(TransactionLocal transactionBean) {
        this.transactionBean = transactionBean;
    }

    public List<TransactionHistory> getHistory() {
        return history;
    }

    public void setHistory(List<TransactionHistory> history) {
        this.history = history;
    }
}

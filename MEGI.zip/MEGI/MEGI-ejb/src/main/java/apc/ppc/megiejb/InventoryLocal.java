package apc.ppc.megiejb;

import javax.ejb.Local;
import java.util.List;

@Local
public interface InventoryLocal {

	public List<InventoryItem> getItems();
	
	public void addItem(InventoryItem item);

	public void deleteItem(InventoryItem item);

	public void updateItem(InventoryItem item);

	InventoryItem findItem(Long itemId);

	public List<InventoryItem> searchByName(String name);

}

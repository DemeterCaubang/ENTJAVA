package apc.ppc.megiejb;

import javax.ejb.Local;
import java.util.List;

@Local
public interface TransactionsLocal {

	public List<TransactionHistory> getItems();
	
	public void addItem(TransactionHistory item);

	public void deleteItem(TransactionHistory item);

	public void updateItem(TransactionHistory item);

	TransactionHistory findItem(Long itemId);

	public List<TransactionHistory> searchByName(String name);

}

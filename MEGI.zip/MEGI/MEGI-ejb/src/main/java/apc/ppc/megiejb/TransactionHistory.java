package apc.ppc.megiejb;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="TRANSACTION_HISTORY")
public class TransactionHistory {

    @Id
    @Column(name="TRANSACTION_HISTORY_ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long itemId;

    @Column(name="NAME")
    private String name;

    @Column(name="ACTION_DONE")
    private String actionDone;

    @Column(name="VALUE_PRICE")
    private int value;

    @Column(name="DATE_OF_TRANSACTION")
    private Date dateOfTransaction;

    public TransactionHistory() {
    }

    public TransactionHistory(String name, String actionDone, int value, Date dateOfTransaction) {
        this.name = name;
        this.actionDone = actionDone;
        this.value = value;
        this.dateOfTransaction = dateOfTransaction;
    }

    public long getItemId() {
        return itemId;
    }

    public void setItemId(long itemId) {
        this.itemId = itemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getActionDone() {
        return actionDone;
    }

    public void setActionDone(String actionDone) {
        this.actionDone = actionDone;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public Date getDateOfTransaction() {
        return dateOfTransaction;
    }

    public void setDateOfTransaction(Date dateOfTransaction) {
        this.dateOfTransaction = dateOfTransaction;
    }

    @Override
    public String toString() {
        return "TransactionHistory{" +
                "itemId=" + itemId +
                ", name='" + name + '\'' +
                ", actionDone='" + actionDone + '\'' +
                ", dateOfTransaction=" + dateOfTransaction +
                '}';
    }
}

package apc.ppc.megiejb;

import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Singleton
@LocalBean
public class Inventory implements InventoryLocal {

	@PersistenceContext
	private EntityManager entityManager;

    public Inventory() {
    }

	@Override
	public List<InventoryItem> getItems() {
		return this.entityManager.createQuery("select i from InventoryItem i", InventoryItem.class).getResultList();
	}

	@Override
	public void addItem(InventoryItem item) {
		this.entityManager.persist(item);
	}

	@Override
	public void deleteItem(InventoryItem item) {
		this.entityManager.remove(this.entityManager.contains(item) ? item:this.entityManager.merge(item));
	}

	@Override
	public void updateItem(InventoryItem item) {
		this.entityManager.createQuery("update InventoryItem i set i.name=:itemName, i.buyingPrice=:itemBuyingPrice where i.itemId=:id")
				.setParameter("id", item.getItemId())
				.setParameter("itemName", item.getName())
				.setParameter("itemBuyingPrice",item.getBuyingPrice())
				.executeUpdate();
	}


	@Override
	public InventoryItem findItem(Long itemId) {
		return this.entityManager.find(InventoryItem.class, itemId);
	}

	@Override
	public List<InventoryItem> searchByName(String name) {
		return this.entityManager.createQuery("select i from InventoryItem i " +
				" where i.name like :name", InventoryItem.class).setParameter("name", "%" + name + "%").getResultList();
	}

}

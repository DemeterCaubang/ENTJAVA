package apc.ppc.megijsf;

import apc.ppc.megiejb.*;

import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;

@Named
@ConversationScoped
public class GameTransactionBean implements Serializable{

    private long itemId;

    private InventoryItem item;

    private String userName="Steve";

    private int money=10000;

    @Inject
    private InventoryLocal inventoryBean;

    @Inject
    private TransactionsLocal transactionBean;

    @Inject
    private Conversation conversation;

    public void fetchItem() {
        conversation.begin();
        this.item=inventoryBean.findItem(this.itemId);
    }

    public String buyItem(){
        this.setMoney(this.getMoney() - this.item.getBuyingPrice());
        java.util.Date date = new java.util.Date();
        this.transactionBean.addItem(new TransactionHistory(this.item.getName(), "Buy", this.item.getBuyingPrice(), date));
        return "buyerReceipt?faces-redirect=true";
    }

    public String sellItem(){
        this.setMoney(this.getMoney() + this.item.getBuyingPrice() + 50);
        java.util.Date date = new java.util.Date();
        this.transactionBean.addItem(new TransactionHistory(this.item.getName(), "Sell", this.item.getBuyingPrice() + 50, date));
        return "sellerReceipt?faces-redirect=true";
    }

    public long getItemId() {
        return itemId;
    }

    public void setItemId(long itemId) {
        this.itemId = itemId;
    }

    public InventoryItem getItem() {
        return item;
    }

    public void setItem(InventoryItem item) {
        this.item = item;
    }

    public InventoryLocal getInventoryBean() {
        return inventoryBean;
    }

    public void setInventoryBean(InventoryLocal inventoryBean) {
        this.inventoryBean = inventoryBean;
    }

    public TransactionsLocal getTransactionBean() {
        return transactionBean;
    }

    public void setTransactionBean(TransactionsLocal transactionBean) {
        this.transactionBean = transactionBean;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }
}

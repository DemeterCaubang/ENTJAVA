package apc.ppc.megijsf;

import apc.ppc.megiejb.TransactionHistory;
import apc.ppc.megiejb.TransactionsLocal;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


@RequestScoped
@Named
public class GameTransactionHistoryBean implements Serializable {

    @Inject
    private TransactionsLocal transactionBean;

    private List<TransactionHistory> history = new ArrayList<>();

    public void init() {
        this.history = this.transactionBean.getItems();
    }

    public TransactionsLocal getTransactionBean() {
        return transactionBean;
    }

    public void setTransactionBean(TransactionsLocal transactionBean) {
        this.transactionBean = transactionBean;
    }

    public List<TransactionHistory> getHistory() {
        return history;
    }

    public void setHistory(List<TransactionHistory> history) {
        this.history = history;
    }
}
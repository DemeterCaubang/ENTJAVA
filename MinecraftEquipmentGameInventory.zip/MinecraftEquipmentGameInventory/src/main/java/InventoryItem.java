public class InventoryItem {
    private int itemId;
    private String name;
    private int buyingPrice;
    public int currentItemId;
    public int money = 10000;

    public InventoryItem() {
    }

    public InventoryItem(int itemId, String name, int buyingPrice) {
        this.itemId = itemId;
        this.name = name;
        this.buyingPrice = buyingPrice;
    }

    public long getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBuyingPrice() {
        return buyingPrice;
    }

    public void setBuyingPrice(int buyingPrice) {
        this.buyingPrice = buyingPrice;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    @Override
    public String toString() {
        return "InventoryItem{" +
                "itemId=" + itemId +
                ", name='" + name + '\'' +
                ", buyingPrice='" + buyingPrice + '\'' +
                ", money=" + money +
                '}';
    }
}
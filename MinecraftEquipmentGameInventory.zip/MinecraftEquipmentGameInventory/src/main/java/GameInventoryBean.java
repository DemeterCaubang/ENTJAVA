import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named
@SessionScoped
public class GameInventoryBean implements Serializable {
    private InventoryItem item = new InventoryItem();
    private InventoryItem currentItem = new InventoryItem();
    private List<InventoryItem> inventory = new ArrayList<>();

    public String init() {
        this.inventory = null;
        this.inventory.add(new InventoryItem(1,"sword",50));
        this.inventory.add(new InventoryItem(2,"pickaxe",100));
        this.inventory.add(new InventoryItem(3,"helmet",450));
        this.inventory.add(new InventoryItem(4,"shield",200));
        this.inventory.add(new InventoryItem(5,"spear",300));
        this.inventory.stream().forEach(item->{
            System.out.println(item.toString());
        });
        return "inventory?faces-redirect=true";
    }

    public String fetchItem(int index) {
        currentItem.setItemId((int) inventory.get(index).getItemId());
        currentItem.setName(inventory.get(index).getName());
        currentItem.setBuyingPrice(inventory.get(index).getBuyingPrice());
        return "checkout?faces-redirect=true";
    }

    public String buyItem() {
        int money = item.getMoney();
        int buyingPrice = currentItem.getBuyingPrice();
		this.item.setMoney( money - buyingPrice);
        return "buyerReceipt?faces-redirect=true";
    }
	
	public String sellItem() {
        int money = item.getMoney();
        int sellingPrice = currentItem.getBuyingPrice() + 50;
		this.item.setMoney( money + sellingPrice);
        return "sellerReceipt?faces-redirect=true";
    }

    public InventoryItem getItem() {
        return item;
    }

    public void setItem(InventoryItem item) {
        this.item = item;
    }

    public InventoryItem getCurrentItem() {
        return currentItem;
    }

    public void setCurrentItem(InventoryItem currentItem) {
        this.currentItem = currentItem;
    }

    public List<InventoryItem> getInventory() {
        return inventory;
    }

    public void setInventory(List<InventoryItem> inventory) {
        this.inventory = inventory;
    }
}

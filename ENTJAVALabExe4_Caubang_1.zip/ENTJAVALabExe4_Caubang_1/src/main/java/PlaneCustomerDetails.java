import java.util.Date;

public class PlaneCustomerDetails {
    private String fName;
    private String lName;
    private Date birthDate;
    private String flightNumber;
    private int ticketFare;

    public PlaneCustomerDetails() {
    }

    public PlaneCustomerDetails(String fName, String lName, Date birthDate, String flightNumber, int ticketFare) {
        this.fName = fName;
        this.lName = lName;
        this.birthDate = birthDate;
        this.flightNumber = flightNumber;
        this.ticketFare = ticketFare;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public int getTicketFare() {
        return ticketFare;
    }

    public void setTicketFare(int ticketFare) {
        this.ticketFare = ticketFare;
    }
}

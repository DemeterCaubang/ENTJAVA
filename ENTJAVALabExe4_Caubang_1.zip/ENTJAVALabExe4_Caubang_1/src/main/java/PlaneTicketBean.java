import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named
@SessionScoped
public class PlaneTicketBean implements Serializable {
    private PlaneCustomerDetails detail = new PlaneCustomerDetails();
    private PlaneFlights flights = new PlaneFlights();
    private List<PlaneCustomerDetails> details = new ArrayList<>();

    public String addTicketDetails() {
        updateTicketDetails();
        this.details.add(new PlaneCustomerDetails(this.detail.getfName(), this.detail.getlName(), this.detail.getBirthDate(), this.detail.getFlightNumber(),this.detail.getTicketFare()));
        this.details.stream().forEach(detail->{
            System.out.println(detail.toString());
        });
        return "ticket?faces-redirect=true";
    }

    private void updateTicketDetails() {

        if(detail.getFlightNumber() == "MNL001") {
            detail.setFlightNumber(flights.getMNL001());
            detail.setTicketFare(flights.getFare1());
        } else if (detail.getFlightNumber() == "MNL002") {
            detail.setFlightNumber(flights.getMNL002());
            detail.setTicketFare(flights.getFare2());
        } else if (detail.getFlightNumber() == "MNL003") {
            detail.setFlightNumber(flights.getMNL003());
            detail.setTicketFare(flights.getFare3());
        } else {
            detail.setFlightNumber(flights.getMNL004());
            detail.setTicketFare(flights.getFare4());
        }
    }

    public PlaneCustomerDetails getDetail() {
        return detail;
    }

    public void setDetail(PlaneCustomerDetails detail) {
        this.detail = detail;
    }

    public PlaneFlights getFlights() {
        return flights;
    }

    public void setFlights(PlaneFlights flights) {
        this.flights = flights;
    }

    public List<PlaneCustomerDetails> getDetails() {
        return details;
    }

    public void setDetails(List<PlaneCustomerDetails> details) {
        this.details = details;
    }
}

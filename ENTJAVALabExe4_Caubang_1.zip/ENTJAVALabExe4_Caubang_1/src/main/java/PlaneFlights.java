public class PlaneFlights {
    private String flightPlace1 = "Manila";
    private String flightPlace2 = "Cebu";
    private String flightPlace3 = "Kalibo";

    private String MNL001 = "MNL001 " + flightPlace1 + " - " + flightPlace2;
    private String MNL002 = "MNL002 " + flightPlace1 + " - " + flightPlace3;
    private String MNL003 = "MNL003 " + flightPlace2 + " - " + flightPlace1;
    private String MNL004 = "MNL004 " + flightPlace3 + " - " + flightPlace1;

    private int fare1 = 3500;
    private int fare2 = 2500;
    private int fare3 = fare1 + 200;
    private int fare4 = fare2 + 200;

    public PlaneFlights() {
    }

    public PlaneFlights(String flightPlace1, String flightPlace2, String flightPlace3, String MNL001, String MNL002, String MNL003, String MNL004, int fare1, int fare2, int fare3, int fare4) {
        this.flightPlace1 = flightPlace1;
        this.flightPlace2 = flightPlace2;
        this.flightPlace3 = flightPlace3;
        this.MNL001 = MNL001;
        this.MNL002 = MNL002;
        this.MNL003 = MNL003;
        this.MNL004 = MNL004;
        this.fare1 = fare1;
        this.fare2 = fare2;
        this.fare3 = fare3;
        this.fare4 = fare4;
    }

    public String getFlightPlace1() {
        return flightPlace1;
    }

    public void setFlightPlace1(String flightPlace1) {
        this.flightPlace1 = flightPlace1;
    }

    public String getFlightPlace2() {
        return flightPlace2;
    }

    public void setFlightPlace2(String flightPlace2) {
        this.flightPlace2 = flightPlace2;
    }

    public String getFlightPlace3() {
        return flightPlace3;
    }

    public void setFlightPlace3(String flightPlace3) {
        this.flightPlace3 = flightPlace3;
    }

    public String getMNL001() {
        return MNL001;
    }

    public void setMNL001(String MNL001) {
        this.MNL001 = MNL001;
    }

    public String getMNL002() {
        return MNL002;
    }

    public void setMNL002(String MNL002) {
        this.MNL002 = MNL002;
    }

    public String getMNL003() {
        return MNL003;
    }

    public void setMNL003(String MNL003) {
        this.MNL003 = MNL003;
    }

    public String getMNL004() {
        return MNL004;
    }

    public void setMNL004(String MNL004) {
        this.MNL004 = MNL004;
    }

    public int getFare1() {
        return fare1;
    }

    public void setFare1(int fare1) {
        this.fare1 = fare1;
    }

    public int getFare2() {
        return fare2;
    }

    public void setFare2(int fare2) {
        this.fare2 = fare2;
    }

    public int getFare3() {
        return fare3;
    }

    public void setFare3(int fare3) {
        this.fare3 = fare3;
    }

    public int getFare4() {
        return fare4;
    }

    public void setFare4(int fare4) {
        this.fare4 = fare4;
    }
}
